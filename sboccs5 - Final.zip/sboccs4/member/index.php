<?php include("conn.php");
	session_start();
	if(!$_SESSION['email']){
		header('location: member_login.php');
		
	}
	else{

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>View Profile</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="fontawesome/css/all.css">
	<link rel="stylesheet" href="view_profile.css">
</head>

<body>

	<!-- Breadcrumb -->
          <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">Member Profile</li>
                <li align="right"><p><a href="member_logout.php">Logout</a></p></li>
            </ol>
         	
          </nav>
    <!-- /Breadcrumb -->

	<?php include("view_specific_user_dom.php");?>
	<?php include("view_all_users.php");?>
	<?php include("update_user.php");?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
 	<script src="ajax.js"></script>
</body>
</html>


<?php 
	}
?>