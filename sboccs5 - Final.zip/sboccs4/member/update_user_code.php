<?php
	include("conn.php");

	if(isset($_POST['id'])){
		$id = mysqli_real_escape_string($conn, $_POST['id']);
		$name = mysqli_real_escape_string($conn, $_POST['name']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);	
		
			//update images
                if($_FILES['image']['name'] != "")
                {
                    $image = $_FILES['image']['name'];
                    $image_tmp = $_FILES['image']['tmp_name'];
                    move_uploaded_file($image_tmp,"../admin/users/$image");
                }
                else
                {
                    $image = $_POST['himage'];
                }
		$update_user = "UPDATE users SET name = '$name', password = '$password', image = '$image' WHERE id ='$id'";
		$update_query = mysqli_query($conn,$update_user);
		if($update_query){
			echo "User Updated Successfully";
		}
	}
?>
