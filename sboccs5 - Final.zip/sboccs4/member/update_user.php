<form id="updUser" enctype="multipart/form-data">
 
  <!-- The Modal To Update Data-->
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Update Member</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
       <span aria-hidden="true" onclick="location.reload(true);">&times;</span> 
      </button>
      </div>
      <input type="hidden" name="id" id="user_id">
      <!-- Modal body To Update Data-->
      <div class="modal-body">
        
        <div class="form-group">
          <label class="control-label"> Name:</label>
          <input type="text" name="name" id="uname" class="form-control" placeholder="Name">
        </div>

        <div class="form-group">
          <label class="control-label"> Password:</label>
          <input type="password" name="password" id="upassword" class="form-control" placeholder="Password">
        </div>        

      <div class="form-group">
          <label class="control-label"> Image:</label>
          <input type="file" name="image" id="uimage" class="form-control" />
          <input type='hidden' id='himage' name='himage' value=''/>
          <div id="pimage"></div>
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button name="updateuser" id="updateuser" class="btn btn-primary" onclick="">Update User</button>
        <button class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>

  </div>
</div>
</form>