<?php
	session_start();
	include("conn.php");	
	$id = $_SESSION['id'];
	
	if($id){
		$displayquery = " SELECT * FROM users WHERE id='$id'"; 
		$fetch = mysqli_query($conn, $displayquery);

	if(mysqli_num_rows($fetch) > 0){

		 $i=0;
		while ($row = mysqli_fetch_assoc($fetch)) {
			$id = $row['id'];
			$membno = $row['membno'];
			$name = $row['name'];
			$email = $row['email'];
			$password = $row['password'];
			$registereddate = $row['registereddate'];
			$sharedcapital = $row['sharedcapital'];
			$thrift = $row['thrift'];
			$mbf = $row['mbf'];
			$longtermloan = $row['longtermloan'];
			$emergencyloan = $row['emergencyloan'];
			$medicalloan = $row['medicalloan'];
			$hrmsno = $row['hrmsno'];
			$image = $row['image'];
			$i++;
?>
<div class="container">
    <div class="main-body">
    
          
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="<?php echo 'users/$image';?>" alt="Member" class="rounded-circle" width="150">
                    <?php echo "<img src='users/$image' width='150' height='150' alt='Member' class='rounded-circle'/>";?>
                    <div class="mt-3">
                 
          <td><?php echo $hrmsno;?></td>
				<td><?php echo "<img src='users/$image' width='100' height='100' />";?></td>
				          	
                      <h4><?php echo $name;?></h4>
                      <p class="text-secondary mb-1">Full Stack Developer</p>
                      <p class="text-muted font-size-sm">Bay Area, San Francisco, CA</p>
                      <a href="" class="btn btn-primary" id="view" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#viewUserModal">View Profile</a>
                      <a href="" class="btn btn-outline-primary" id="edit" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#editUserModal">Edit Profile</a>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="col-md-8">
              	
          </div>
          </div>
        </div>
    </div>
<table class="table table-responsive table-bordered table-striped table-hover">
	<thead>
		<tr>
			<th>Welcome <?php echo $name;?></th>
		</tr>
	</thead>
	<tbody id="userdata">
	


			<tr class="table">
					<td>Shared Capital:</td><td><?php echo $sharedcapital;?></td></tr>
				<tr>
					<td>Thrift:</td><td><?php echo $thrift;?></td>
				</tr>
				<tr>
					<td>MBF: </td><td><?php echo $mbf;?></td>
				</tr>

				<tr>
					<td>Long Term Loan: </td><td><?php echo $longtermloan;?></td>
				</tr>
				<tr>
					<td>Emergency Loan: </td><td><?php echo $emergencyloan;?></td>
				</tr>
				<tr>
					<td>Medical Loan: </td><td><?php echo $medicalloan;?></td>				
				
    		</tr>


<?php
	}
}	
else{ 
	?>

	<tr><td>No Data Found</td></tr>
		
<?php	
}

}

else{
	echo "No User Found";
}
?>


