<!--To Display view data modal-->
<div class="modal fade" id="viewUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">VIEW USER DETAILS</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" onclick="location.reload(true);">&times;</span>
        </button>
      </div>

      <!-- Modal body for view user-->
      <div class="modal-body">
        <table class="table table-bordered table-striped">
          <tbody>
            <tr>
              <td colspan="2"><span id="view_image"></span></td>
            </tr>
            <tr>
              <td>Member No.</td>
              <td><span id="view_membno"></span></td>
            </tr>
            <tr>
              <td>Name</td>  
              <td><span id="view_name"></span></td>
            </tr>
            <tr>
              <td>email</td>  
              <td><span id="view_email"></span></td>
            </tr>
            <tr>
              <td>Registered Date</td> 
              <td><span id="view_registereddate"></span></td>
            </tr>
            <tr>
              <td>Shared Capital</td>
              <td><span id="view_sharedcapital"></span></td>
            </tr>
            <tr>
              <td>Thrift</td>
              <td><span id="view_thrift"></span></td>
            </tr>
            <tr>
              <td>MBF</td>
              <td><span id="view_mbf"></span></td>
            </tr>
            <tr>
              <td>Long Term Loan</td>
              <td><span id="view_longtermloan"></span></td>
            </tr>
            <tr>
              <td>Emergency Loan</td>
              <td><span id="view_emergencyloan"></span></td>
            </tr>
            <tr>
              <td>Medical Loan</td>
              <td><span id="view_medicalloan"></span></td>
            </tr>
            <tr>
              <td>HRMS No.</td>
              <td><span id="view_hrmsno"></span></td>
            </tr>            
          </tbody>  
        </table>

      </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="location.reload(true);">Close</button>
    </div> 
  </div>
 </div>
</div>     
