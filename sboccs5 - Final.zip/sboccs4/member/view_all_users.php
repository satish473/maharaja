<?php


$user = $_SESSION['email'];

$get_user = "SELECT * from users WHERE email = '$user'";
$run_user = mysqli_query($conn,$get_user);



  $row=mysqli_fetch_array($run_user);    

      $id = $row['id'];
      $membno = $row['membno'];
      $name = $row['name'];
      $email = $row['email'];
      $password = $row['password'];
      $registereddate = $row['registereddate'];
      $sharedcapital = $row['sharedcapital'];
      $thrift = $row['thrift'];
      $mbf = $row['mbf'];
      $longtermloan = $row['longtermloan'];
      $emergencyloan = $row['emergencyloan'];
      $medicalloan = $row['medicalloan'];
      $hrmsno = $row['hrmsno'];
      $image = $row['image'];
      $ex1 = $row['ex1'];
      $ex2 = $row['ex2'];
      $ex3 = $row['ex3'];
      $ex4 = $row['ex4'];
      $ex5 = $row['ex5'];
      $ex6 = $row['ex6'];

if($password == "Sboccs@123" || $image == "default.png"){
  echo "<a href='' class='btn btn-outline-primary' id='edit' data-val=$id data-toggle='modal' data-target='#editUserModal'>Edit Profile</a>" . "<br>";
  echo "Please change your Password and Profile pic. Thank You..!";
}
 else
 {
?>



<div class="container">

  <div class="row">

  <div class="col-md-4">
    	<table class='table table-bordered table-hover'  id="userdata">
      <thead>
        <tr align="center">
          <th colspan="2"><?php echo "<img src='../admin/users/$image' width='150' height='150' style='border-radius:100px; border:1px solid lightgrey;'>";?></th>

         </tr>
      </thead>
      <tbody>    
          <tr><th>Member No:</th><td><?php echo $membno;?></td></tr>
          <tr><th>Name:</th><td><?php echo $name;?></td></tr>
          <tr><th>HRMS No:</th><td><?php echo $hrmsno;?></td></tr>
          <tr><th>email</th><td><?php echo $email;?></td></tr>
          <tr><td><a href="" class="btn btn-primary" id="view" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#viewUserModal">View Profile</a></td>
          <td><a href="" class="btn btn-outline-primary" id="edit" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#editUserModal">Edit Profile</a></td></tr>        
      </tbody>
      </table>

  </div>

  <div class="col-md-8">
    <table class="table table-bordered table-striped table-hover text-uppercase">
    
    <tr><th>registered date</th><td><?php echo $registereddate;?></td></tr> 
    <tr><th>share capital</th><td><?php echo $sharedcapital;?></td></tr>
    <tr><th>thrift</th><td><?php echo $thrift;?></td></tr>
    <tr><th>mbf</th><td><?php echo $mbf;?></td></tr>
    <tr><th>long term loan</th><td><?php echo $longtermloan;?></td></tr>
    <tr><th>emergency loan</th><td><?php echo $emergencyloan;?></td></tr>
    <tr><th>medical loan</th><td><?php echo $medicalloan;?></td></tr>          
          
        
    </table>    
  </div>
  </div>
</div>   
  <div class="container">
    <div class="col-md-4">
    <table class="table table-bordered table-striped table-hover">
      <tr align="center">
        <th colspan="2">Others</th>
      </tr>
      <tr>
        <td><?php echo $ex1;?></td>
        <td><?php echo $ex2;?></td>
      </tr>
      <tr>
        <td><?php echo $ex3;?></td>
        <td><?php echo $ex4;?></td>
      </tr>
      <tr>
        <td><?php echo $ex5;?></td>
        <td><?php echo $ex6;?></td>
      </tr>

    </table>
  </div>
  </div>

  <?php 
}
?>