//    Fetch User Profile
  function getAllUsers(){
    $.ajax({
    url: "fetch.php",
    success: function(data){ 
      $("#userdata").html(data);
      //alert(data);
        
       } 

    }); 
  }

//To View the details of specific User
$(document).on('click', '#view', function(){
  var id = $(this).attr('data-val');
    $.ajax({
      url: 'viewUser.php',
      type: "POST", 
      data: {
        id:id,
      },

      dataType: "JSON",
      success: function(data){
        //var data = $.parseJSON(data);  
         //$('#image').attr('src',data.image);
        var img = $('<img id="view_image" width="100px" height="100px" style="margin-left:auto;margin-right:auto;display:block;border-radius:50%;">');
          //img.attr('src', data.image);
        //document.createElement('img');

          img.attr('src', " ../admin/users/"+data.image);
          img.appendTo('#view_image');
            $('#view_membno').text(data.membno);
            $('#view_name').text(data.name);
            $('#view_email').text(data.email);
            //$('#view_password').text(data.password);
            $('#view_registereddate').text(data.registereddate);
            $('#view_sharedcapital').text(data.sharedcapital);
            $('#view_thrift').text(data.thrift);
            $('#view_mbf').text(data.mbf);
            $('#view_longtermloan').text(data.longtermloan);
            $('#view_emergencyloan').text(data.emergencyloan);
            $('#view_medicalloan').text(data.medicalloan);
            $('#view_hrmsno').text(data.hrmsno);
            // alert(data.image);

    } 
  });
  });

 //To Edit the Records
 $(document).on('click', '#edit', function(){
    var id = $(this).attr('data-val');
    //alert(id);
    $.ajax({
      url: 'viewUser.php',
      type: "POST",
      data: {id:id},

      success: function(data){
        var json = $.parseJSON(data);
        //alert(json.image);
        $('#user_id').val(json.id);
        $('#uname').val(json.name);
        $('#upassword').val(json.password);
        
        var img = $('<img id="image" width="100" height="100" id="image">');
        img.attr('src', " ../admin/users/"+json.image);
        $("#himage").val(json.image);
        img.appendTo('#pimage');
       }
     });

 });

 $(document).ready(function(){
    $("#updateuser").click(function(e){

        e.preventDefault();
        var form_data = new FormData($('#updUser')[0]);
        var fileToUpload = $('#uimage').prop('files')[0];
        
        var id = $('#user_id').val();
        var name = $('#uname').val();
        var password = $('#upassword').val();
        var image = (fileToUpload !== undefined) ? fileToUpload : $('#himage').val();
        
      if(name !="" && password !="")
          {
            $.ajax({
              url: "update_user_code.php",
              type: "POST",
              data: form_data,
              processData: false,
              contentType: false,
              success: function(data)
                {
                  $("#editUserModal").hide();
                  alert(data);
                  location.reload();
                  // console.log(data);
                  // return false;
                }
              });
          }
            else{
              alert("Please Fill all the details");
            }
        });

    });