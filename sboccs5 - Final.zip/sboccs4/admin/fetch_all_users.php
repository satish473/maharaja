<div class="container overflow-auto" >
    
        <h1 class="text-primary text-uppercase text-center" align="center">Members Information</h1>
        
            <table id='empTable' class='table table-responsive table-bordered table-striped table-hover display dataTable'>
                <thead>
                <tr>
                    <th>id</th>
                    <th>membno</th>
                    <th>name</th>
                    <th>email</th>
                    <th>password</th>    
                    <th>registereddate</th>
                    <th>sharedcapital</th>
                    <th>thrift</th>
                    <th>mbf</th> 
                    <th>longtermloan</th>
                    <th>emergencyloan</th>
                    <th>medicalloan</th>
                    <th>hrmsno</th>
                    <th>Others1</th>
                    <th>Others2</th>
                    <th>Others3</th>
                    <th>Others4</th>
                    <th>Others5</th>
                    <th>Others6</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
                </thead>
                 
            </table>
        
   
</div>