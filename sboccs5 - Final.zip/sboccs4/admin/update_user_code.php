<?php
	include("conn.php");

	if(isset($_POST['id'])){
		$id = mysqli_real_escape_string($conn, $_POST['id']);
		$membno = mysqli_real_escape_string($conn, $_POST['membno']);
		$name = mysqli_real_escape_string($conn, $_POST['name']);
		$email = mysqli_real_escape_string($conn, $_POST['email']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);	
		$registereddate = mysqli_real_escape_string($conn, $_POST['registereddate']);
		$sharedcapital = mysqli_real_escape_string($conn, $_POST['sharedcapital']);
		$thrift = mysqli_real_escape_string($conn, $_POST['thrift']);
		$mbf = mysqli_real_escape_string($conn, $_POST['mbf']);	
		$longtermloan = mysqli_real_escape_string($conn, $_POST['longtermloan']);
		$emergencyloan = mysqli_real_escape_string($conn, $_POST['emergencyloan']);
		$medicalloan = mysqli_real_escape_string($conn, $_POST['medicalloan']);
		$hrmsno = mysqli_real_escape_string($conn, $_POST['hrmsno']);
		$ex1 = mysqli_real_escape_string($conn, $_POST['ex1']);		
		$ex2 = mysqli_real_escape_string($conn, $_POST['ex2']);
		$ex3 = mysqli_real_escape_string($conn, $_POST['ex3']);
		$ex4 = mysqli_real_escape_string($conn, $_POST['ex4']);
		$ex5 = mysqli_real_escape_string($conn, $_POST['ex5']);
		$ex6 = mysqli_real_escape_string($conn, $_POST['ex6']);
			//update images
                if($_FILES['image']['name'] != "")
                {
                    $image = $_FILES['image']['name'];
                    $image_tmp = $_FILES['image']['tmp_name'];
                    move_uploaded_file($image_tmp,"users/$image");
                }
                else
                {
                    $image = $_POST['himage'];
                }
		$update_user = "UPDATE users SET membno = '$membno', name = '$name', email = '$email', password = '$password', registereddate = '$registereddate', sharedcapital = '$sharedcapital', thrift = '$thrift', mbf = '$mbf', longtermloan = '$longtermloan', emergencyloan = '$emergencyloan', medicalloan = '$medicalloan', hrmsno = '$hrmsno', image = '$image', ex1 = '$ex1', ex2 = '$ex2', ex3 = '$ex3', ex4 = '$ex4', ex5 = '$ex5', ex6 = '$ex6' WHERE id ='$id'";
		$update_query = mysqli_query($conn,$update_user);
		if($update_query){
			echo "User Updated Successfully";
		}
	}
?>
