<?php
include('conn.php');
$draw = $_POST['draw'];  
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = mysqli_real_escape_string($conn,$_POST['search']['value']); // Search value
 
## Search 
$searchQuery = " ";
if($searchValue != ''){
   $searchQuery .= " and (name like '%".$searchValue."%' or
            email like '%".$searchValue."%' or
            membno like'%".$searchValue."%' or
            hrmsno like'%".$searchValue."%' or
            image like'%".$searchValue."%') ";
}
 
## Total number of records without filtering
$sel = mysqli_query($conn,"select count(*) as allcount from users");
$records = mysqli_fetch_assoc($sel);
$totalRecords = $records['allcount'];
 
## Total number of records with filtering
$sel = mysqli_query($conn,"select count(*) as allcount from users WHERE 1 ".$searchQuery);
$records = mysqli_fetch_assoc($sel);
$totalRecordwithFilter = $records['allcount'];
 
## Fetch records
$empQuery = "select * from users WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
$empRecords = mysqli_query($conn, $empQuery);
 
$data = array();
 
while($row = mysqli_fetch_assoc($empRecords)){
    $id = $row['id'];
    $membno = $row['membno'];
    //$salaryarray = "$ $salary";
    $image = $row['image'];
    $data[] = array(
            "id"=>$row['id'],
            "membno"=>$row['membno'],
            "name"=>$row['name'],
            "email"=>$row['email'],
            "password"=>$row['password'],
            "registereddate"=>$row['registereddate'],
            "sharedcapital"=>$row['sharedcapital'],
            "thrift"=>$row['thrift'],
            "mbf"=>$row['mbf'],
            "longtermloan"=>$row['longtermloan'],
            "emergencyloan"=>$row['emergencyloan'],
            "medicalloan"=>$row['medicalloan'],
            "hrmsno"=>$row['hrmsno'],
            "ex1"=>$row['ex1'],
            "ex2"=>$row['ex2'],
            "ex3"=>$row['ex3'],
            "ex4"=>$row['ex4'],
            "ex5"=>$row['ex5'],
            "ex6"=>$row['ex6'],
            "image"=> "<img src='users/$image' width='100' height='100' />",
            "action"=>"<ul class='list-group' id='actions'>
                    <li class='list-group-item'>
                        <a class='' href='' id='view' data-val=$id data-toggle='modal' data-target='#viewUserModal'>
                        <i class='fa fa-eye fa-2x'></i> </a>
                        <a class='' href='' id='edit' data-val=$id data-toggle='modal' data-target='#editUserModal'>
                            <i class='fa fa-edit fa-2x'></i></a> 
                        <a class='' href='' id='delete' data-val= $id>
                            <i class='fa fa-trash fa-2x'></i></a>
                    </li>
                </ul>"
        );
}


 
## Response
$response = array(
    "draw" => intval($draw),
    "iTotalRecords" => $totalRecords,
    "iTotalDisplayRecords" => $totalRecordwithFilter,
    "aaData" => $data
);
 
echo json_encode($response);
 
?>