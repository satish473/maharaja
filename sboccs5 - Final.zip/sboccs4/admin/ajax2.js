
    $(document).ready(function(){

// Insert Data   
      $('#uploadUser').submit(function(e){

      e.preventDefault();
      
      var membno = $('#membno').val();
      var name = $('#name').val();
      var email = $('#email').val();
      var password = $('#password').val(); 
      var registereddate = $('#registereddate').val();
      var sharedcapital = $('#sharedcapital').val();
      var thrift = $('#thrift').val();
      var mbf = $('#mbf').val(); 
      var longtermloan = $('#longtermloan').val();
      var emergencyloan = $('#emergencyloan').val();
      var medicalloan = $('#medicalloan').val();
      var hrmsno = $('#hrmsno').val();
      var image = $('#image').val();

        $.ajax({
        url: $(this).attr('action'),
        //url: 'insert_user.php',
        type: 'post',
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success:function(data){ 
          $("#addPostModal").hide();
          location.reload();
          
        }, error: function(){

        }   
      });
    
    });

});

//Fetch and Pagination
$(document).ready(function() {
  load_data();
    function load_data(page)
    {
      $.ajax({
        url: "pagination.php",
        method: "POST",
        data:{page:page},
        success:function(data){
         $('#pagination_data').html(data); 
        }
      });
    }

    $(document).on('click','.pagination_link', function(){
        var page = $(this).attr("id");
        load_data(page);
    });

});


//Search

// $(document).ready(function(){
//     $("pagination_data").hide();
//     $('#search_text').keyup(function){
//       var txt = ($this).val();
//         if(txt != '')
//         {

//         } 
//         else
//         {
//           $('#result').html('');
//               url:"search.php",
//               method: "post",
//               data:{search:txt},
//               dataType:"text",
//               success:function(data)
//                 {
//                   $('#search_result').html(data);
//                 }
//         }    

// });

// });

        
//To View the details of specific User
$(document).on('click', '#view', function(){
  var id = $(this).attr('data-val');
    $.ajax({
      url: 'viewUser.php',
      type: "POST", 
      data: {
        id:id,
      },

      dataType: "JSON",
      success: function(data){
        //var data = $.parseJSON(data);  
         //$('#image').attr('src',data.image);
        var img = $('<img id="view_image" width="100px" height="100px" style="margin-left:auto;margin-right:auto;display:block;border-radius:50%;">');
          //img.attr('src', data.image);
        //document.createElement('img');

          img.attr('src', "images/"+data.image);
          img.appendTo('#view_image');
            $('#view_membno').text(data.membno);
            $('#view_name').text(data.name);
            $('#view_email').text(data.email);
            //$('#view_password').text(data.password);
            $('#view_registereddate').text(data.registereddate);
            $('#view_sharedcapital').text(data.sharedcapital);
            $('#view_thrift').text(data.thrift);
            $('#view_mbf').text(data.mbf);
            $('#view_longtermloan').text(data.longtermloan);
            $('#view_emergencyloan').text(data.emergencyloan);
            $('#view_medicalloan').text(data.medicalloan);
            $('#view_hrmsno').text(data.hrmsno);
            // alert(data.image);

    } 
  });
  });

 //To Edit the Records
 $(document).on('click', '#edit', function(){
    var id = $(this).attr('data-val');
    //alert(id);
    $.ajax({
      url: 'viewUser.php',
      type: "POST",
      data: {id:id},

      success: function(data){
        var json = $.parseJSON(data);
        //alert(json.image);
        $('#user_id').val(json.id);
        $('#umembno').val(json.membno);
        $('#uname').val(json.name);
        $('#uemail').val(json.email);
        $('#upassword').val(json.password);
        $('#uregistereddate').val(json.registereddate);
        $('#usharedcapital').val(json.sharedcapital);
        $('#uthrift').val(json.thrift);
        $('#umbf').val(json.mbf);
        $('#ulongtermloan').val(json.longtermloan);
        $('#uemergencyloan').val(json.emergencyloan);
        $('#umedicalloan').val(json.medicalloan);
        $('#uhrmsno').val(json.hrmsno);
        
        var img = $('<img id="image" width="100" height="100" id="image">');
        img.attr('src', "images/"+json.image);
        $("#himage").val(json.image);
        img.appendTo('#pimage');
       }
     });

 });

 $(document).ready(function(){
    $("#updateuser").click(function(e){

        e.preventDefault();
        var form_data = new FormData($('#updUser')[0]);
        var fileToUpload = $('#uimage').prop('files')[0];
        
        var id = $('#user_id').val();
        var membno = $('#umembno').val();
        var name = $('#uname').val();
        var email = $('#uemail').val();
        var password = $('#upassword').val();
        var registereddate = $('#uregistereddate').val();
        var sharedcapital = $('#usharedcapital').val();
        var thrift = $('#uthrift').val();
        var mbf = $('#umbf').val();
        var longtermloan = $('#ulongtermloan').val();
        var emergencyloan = $('#uemergencyloan').val();
        var medicalloan = $('#umedicalloan').val();
        var hrmsno = $('#uhrmsno').val();
        var image = (fileToUpload !== undefined) ? fileToUpload : $('#himage').val();
        
      if(membno !="" && name !="" && email !="" && password !="" && registereddate !="" && password !="" && sharedcapital !="" && thrift !="" && mbf !="" && longtermloan !=""&& emergencyloan !="" && medicalloan !="" && hrmsno !="")
          {
            $.ajax({
              url: "update_user_code.php",
              type: "POST",
              data: form_data,
              processData: false,
              contentType: false,
              success: function(data)
                {
                  $("#editUserModal").hide();
                  alert(data);
                  location.reload();
                  // console.log(data);
                  // return false;
                }
              });
          }
            else{
              alert("Please Fill all the details");
            }
        });

    });

// //To Delete Record
$(document).on('click', '#delete', function(){
  var id = $(this).attr('data-val');
  $.ajax({
    url: 'delete.php',
    type: "POST",
    data: {id:id},

    success: function(data){
      alert(data);
    }
  });
});

