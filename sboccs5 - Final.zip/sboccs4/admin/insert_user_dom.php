
 
<form action="insert_user.php" method="post" id="uploadUser" enctype="multipart/form-data">
  <!-- The Modal To Add Data-->
<div class="modal" id="addPostModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">DETAILS OF MEMBER</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body To Add Data-->
      <div class="modal-body">
        <div class="form-group">
          <label> Member No:</label>
          <input type="text" name="membno" id="membno" class="form-control" placeholder="Member No">
        </div>
        <div class="form-group">
          <label> Name:</label>
          <input type="text" name="name" id="name" class="form-control" placeholder="Name">
        </div>

        <div class="form-group">
          <label> Email Id:</label>
          <input type="email" name="email" id="email" class="form-control" placeholder="Email">
        </div>

        <div class="form-group">
          <label> Password:</label>
          <input type="password" name="password" id="password" class="form-control" placeholder="Password">
        </div>

        <div class="form-group">
          <label> Registered Date:</label>
          <input type="date" name="registereddate" id="registereddate" class="form-control" placeholder="Registere Ddate">
        </div>

        <div class="form-group">
          <label> Shared Capital:</label>
          <input type="text" name="sharedcapital" id="sharedcapital" class="form-control" placeholder="Shared Capital">
        </div>

        <div class="form-group">
          <label> Thrift:</label>
          <input type="text" name="thrift" id="thrift" class="form-control" placeholder="Thrift">
        </div>
  
        <div class="form-group">
          <label> MBF:</label>
          <input type="text" name="mbf" id="mbf" class="form-control" placeholder="MBF">
        </div>

        <div class="form-group">
          <label> Long Term Loan:</label>
          <input type="text" name="longtermloan" id="longtermloan" class="form-control" placeholder="Long Term Loan">
        </div>

        <div class="form-group">
          <label> Emergency Loan:</label>
          <input type="text" name="emergencyloan" id="emergencyloan" class="form-control" placeholder="Emergency Loan">
        </div>

        <div class="form-group">
          <label> Medical Loan:</label>
          <input type="text" name="medicalloan" id="medicalloan" class="form-control" placeholder="Medical Loan">
        </div>

        <div class="form-group">
          <label> HRMS No:</label>
          <input type="text" name="hrmsno" id="hrmsno" class="form-control" placeholder="HRMS No">
        </div>

      <div class="form-group">
          <label> Others1:</label>
          <input type="text" name="ex1" id="ex1" class="form-control" placeholder="Others1">
        </div>
      <div class="form-group">
          <label> Others2:</label>
          <input type="text" name="ex2" id="ex2" class="form-control" placeholder="Others2">
        </div>
       <div class="form-group">
          <label> Others31:</label>
          <input type="text" name="ex3" id="ex3" class="form-control" placeholder="Others3">
        </div>
      <div class="form-group">
          <label> Others4:</label>
          <input type="text" name="ex4" id="ex4" class="form-control" placeholder="Others4">
        </div>
      <div class="form-group">
          <label> Others5:</label>
          <input type="text" name="ex5" id="ex5" class="form-control" placeholder="Others5">
        </div>
      <div class="form-group">
          <label> Others6:</label>
          <input type="text" name="ex6" id="ex6" class="form-control" placeholder="Others6">
        </div>   

      <div class="form-group">
          <label> Image:</label>
          <input type="file" name="image" id="image" class="form-control">
        </div>
      </div>  

      <!-- Modal footer -->
      <div class="modal-footer">
        <button name="adduser" class="btn btn-primary" onclick="location.reload(true);">Add User</button>
        <button class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>

  </div>
</div>

  </form>

