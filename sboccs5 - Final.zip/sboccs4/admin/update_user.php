<form id="updUser" enctype="multipart/form-data">
 
  <!-- The Modal To Update Data-->
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Update Member</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
       <span aria-hidden="true" onclick="location.reload(true);">&times;</span> 
      </button>
      </div>
      <input type="hidden" name="id" id="user_id">
      <!-- Modal body To Update Data-->
      <div class="modal-body">
        <div class="form-group">
          <label class="control-label"> Member No:</label>
          <input type="text" name="membno" id="umembno"  class="form-control" placeholder="Member No:">
        </div>
        <div class="form-group">
          <label class="control-label"> Name:</label>
          <input type="text" name="name" id="uname" class="form-control" placeholder="Name">
        </div>

        <div class="form-group">
          <label class="control-label"> Email Id:</label>
          <input type="email" name="email" id="uemail" class="form-control" placeholder="Email">
        </div>

        <div class="form-group">
          <label class="control-label"> Password:</label>
          <input type="password" name="password" id="upassword" class="form-control" placeholder="Password">
        </div>

        <div class="form-group">
          <label class="control-label"> Registered Date:</label>
          <input type="date" name="registereddate" id="uregistereddate" class="form-control" placeholder="Date">
        </div>

        <div class="form-group">
          <label class="control-label"> Shared Capital:</label>
          <input type="text" name="sharedcapital" id="usharedcapital" class="form-control" placeholder="Shared Capital">
        </div>

        <div class="form-group">
          <label class="control-label"> Thrift:</label>
          <input type="text" name="thrift" id="uthrift" class="form-control" placeholder="Thrift">
        </div>

        <div class="form-group">
          <label class="control-label"> MBF:</label>
          <input type="text" name="mbf" id="umbf" class="form-control" placeholder="MBF">
        </div>

        <div class="form-group">
          <label class="control-label"> Long Term Loan:</label>
          <input type="text" name="longtermloan" id="ulongtermloan" class="form-control" placeholder="Long Term Loan">
        </div>

        <div class="form-group">
          <label class="control-label"> Emergency Loan:</label>
          <input type="text" name="emergencyloan" id="uemergencyloan" class="form-control" placeholder="Emergency Loan">
        </div>

        <div class="form-group">
          <label class="control-label"> Medical Loan:</label>
          <input type="text" name="medicalloan" id="umedicalloan" class="form-control" placeholder="Medical Loan">
        </div>

        <div class="form-group">
          <label class="control-label"> HRMS No:</label>
          <input type="text" name="hrmsno" id="uhrmsno" class="form-control" placeholder="HRMS No">
        </div>
        
        <div class="form-group">
          <label class="control-label"> Others1:</label>
          <input type="text" name="ex1" id="uex1" class="form-control" placeholder="Others1">
        </div>

        <div class="form-group">
          <label class="control-label"> Others2:</label>
          <input type="text" name="ex2" id="uex2" class="form-control" placeholder="Others2">
        </div>

        <div class="form-group">
          <label class="control-label"> Others3:</label>
          <input type="text" name="ex3" id="uex3" class="form-control" placeholder="Others3">
        </div>

        <div class="form-group">
          <label class="control-label"> Others4:</label>
          <input type="text" name="ex4" id="uex4" class="form-control" placeholder="Others4">
        </div>

        <div class="form-group">
          <label class="control-label"> Others5:</label>
          <input type="text" name="ex5" id="uex5" class="form-control" placeholder="Others5">
        </div>

        <div class="form-group">
          <label class="control-label"> Others6:</label>
          <input type="text" name="ex6" id="uex6" class="form-control" placeholder="Others6">
        </div>

      <div class="form-group">
          <label class="control-label"> Image:</label>
          <input type="file" name="image" id="uimage" class="form-control" />
          <input type='hidden' id='himage' name='himage' value=''/>
          <div id="pimage"></div>
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button name="updateuser" id="updateuser" class="btn btn-primary" onclick="">Update User</button>
        <button class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>

  </div>
</div>
</form>