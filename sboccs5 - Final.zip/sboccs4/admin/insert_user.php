<?php

//Insert Data
if($_SERVER['REQUEST_METHOD'] == 'POST'){

	include("conn.php");

	$membno = mysqli_real_escape_string($conn, $_POST['membno']);
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);	
	$registereddate = mysqli_real_escape_string($conn, $_POST['registereddate']);
	$sharedcapital = mysqli_real_escape_string($conn, $_POST['sharedcapital']);
	$thrift = mysqli_real_escape_string($conn, $_POST['thrift']);
	$mbf = mysqli_real_escape_string($conn, $_POST['mbf']);	
	$longtermloan = mysqli_real_escape_string($conn, $_POST['longtermloan']);
	$emergencyloan = mysqli_real_escape_string($conn, $_POST['emergencyloan']);
	$medicalloan = mysqli_real_escape_string($conn, $_POST['medicalloan']);
	$hrmsno = mysqli_real_escape_string($conn, $_POST['hrmsno']);
	$ex1 = mysqli_real_escape_string($conn, $_POST['ex1']);
	$ex2 = mysqli_real_escape_string($conn, $_POST['ex2']);
	$ex3 = mysqli_real_escape_string($conn, $_POST['ex3']);
	$ex4 = mysqli_real_escape_string($conn, $_POST['ex4']);
	$ex5 = mysqli_real_escape_string($conn, $_POST['ex5']);
	$ex6 = mysqli_real_escape_string($conn, $_POST['ex6']);


	//image upload	
	$image = $_FILES['image']['name'];
	$image_tmp = $_FILES['image']['tmp_name'];

	move_uploaded_file($image_tmp, "users/$image");
	
	$insert = "INSERT INTO users(membno, name, email, password, registereddate, sharedcapital, thrift, mbf, longtermloan, emergencyloan, medicalloan, hrmsno, image, ex1, ex2, ex3, ex4, ex5, ex6) VALUES ('$membno','$name','$email','$password','$registereddate','$sharedcapital','$thrift','$mbf','$longtermloan','$emergencyloan','$medicalloan','$hrmsno','$image','$ex1','$ex2','$ex3','$ex4','$ex5','$ex6')";
	
	$insert_query = mysqli_query($conn,$insert);

		// if($insert_query){
		// 	echo "<script>alert('User Added Successfully..!)</script>";
		// } else {
		// 	echo "<script>alert('User Not Added')</script>";
		// }

}

?>