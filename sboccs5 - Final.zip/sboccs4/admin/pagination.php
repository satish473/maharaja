<?php
	//pagination
include("conn.php");

$record_per_page = 5;
$page ='';
$output ='';


if(isset($_POST['page']))
{

	// $start = (($_POST["page"] -1) * $record_per_page);
	$page = $_POST["page"];

}
else{
	$page = 1;
}

$start_from = ($page - 1)*$record_per_page;

$pagination_query = "SELECT * FROM `users` ORDER BY 1 DESC LIMIT $start_from, $record_per_page";

$result = mysqli_query($conn,$pagination_query);

?>

<table class='table table-responsive table-bordered table-hover' >
  <thead>
    <tr class='text-uppercase'>
      <th>Id</th>
      <th>memb no</th>
      <th>name</th>
      <th>email</th>
      <th>password </th> 
      <th>registered date</th> 
      <th>shared capital</th>
      <th>thrift</th>
      <th>mbf</th>
      <th>long term loan</th>
      <th>emergency loan</th>
      <th>medical loan</th>
      <th>hrms no</th>
      <th>image</th>
      <th>Others1</th>
      <th>Others2</th>
      <th>Others3</th>
      <th>Others4</th>
      <th>Others5</th>
      <th>Others6</th>
      <th>Action</th>
    </tr>
  </thead>
<tbody>

<?php
	if(mysqli_num_rows($result) > 0){

		 $i=0;
		while ($row = mysqli_fetch_assoc($result)) {
			$id = $row['id'];
			$membno = $row['membno'];
			$name = $row['name'];
			$email = $row['email'];
			$password = $row['password'];
			$registereddate = $row['registereddate'];
			$sharedcapital = $row['sharedcapital'];
			$thrift = $row['thrift'];
			$mbf = $row['mbf'];
			$longtermloan = $row['longtermloan'];
			$emergencyloan = $row['emergencyloan'];
			$medicalloan = $row['medicalloan'];
			$hrmsno = $row['hrmsno'];
			$image = $row['image'];
			$ex1 = $row['ex1'];
			$ex2 = $row['ex2'];
			$ex3 = $row['ex3'];
			$ex4 = $row['ex4'];
			$ex5 = $row['ex5'];
			$ex6 = $row['ex6'];
			$i++;
      ?>
			<tr class="table">
				<td scope="row"><?php echo $id;?></td>
				<td><?php echo $membno;?></td>
				<td><?php echo $name;?></td>
				<td><?php echo $email;?></td>
				<td><?php echo $password;?></td>
				<td><?php echo $registereddate;?></td>
				<td><?php echo $sharedcapital;?></td>
				<td><?php echo $thrift;?></td>
				<td><?php echo $mbf;?></td>
				<td><?php echo $longtermloan;?></td>
				<td><?php echo $emergencyloan;?></td>
				<td><?php echo $medicalloan;?></td>
				<td><?php echo $hrmsno;?></td>	
				<td><?php echo $ex1;?></td>
				<td><?php echo $ex2;?></td>
				<td><?php echo $ex3;?></td>
				<td><?php echo $ex4;?></td>
				<td><?php echo $ex5;?></td>
				<td><?php echo $ex6;?></td>
				<td><?php echo "<img src='users/$image' width='100' height='100' />";?></td>
				<td>
				<ul class="list-group" id="actions">
					<li class="list-group-item">
						<a href="" id="view" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#viewUserModal">
						<i class="fa fa-eye fa-2x"></i> </a>
					<a class="" href="" id="edit" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#editUserModal">
						<i class="fa fa-edit fa-2x"></i></a> 
					<a class="" href="" id="delete" data-val="<?php echo $id;?>">
						<i class="fa fa-trash fa-2x"></i></a>
					</li>
				</ul>	
				</td>
				
    		</tr>

<?php
	}
}	
	?>
</tbody>
  </table>





  <div class="container autoflow-auto" align="center">

	<?php
		$output=''; 
	  $page_query ="SELECT * FROM users ORDER BY 1 DESC";
	  $page_result = mysqli_query($conn,$page_query);
	  $total_records = mysqli_num_rows($page_result);
	  $total_pages = ceil($total_records/ $record_per_page);
	  $j;  
	    for($j = 1; $j <= $total_pages; $j++)
	    {
	      $output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".$j."'>".$j."</span>";
	    }

echo $output;

	?>  

	</div>