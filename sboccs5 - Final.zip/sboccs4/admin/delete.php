<?php
	include('conn.php');
	if(isset($_POST['id'])){
		$id = $_POST['id'];
		$delete = "DELETE FROM users WHERE id = '$id'";
		$delete_query = mysqli_query($conn,$delete);
		if($delete_query){
			echo "Record Deleted Successfully";
		}
	}
?>