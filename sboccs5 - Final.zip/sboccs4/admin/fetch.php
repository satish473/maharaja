	<?php
	include("conn.php");	
	
		$displayquery = " SELECT * FROM users order by 1 DESC"; 
		$fetch = mysqli_query($conn, $displayquery);

	if(mysqli_num_rows($fetch) > 0){

		 $i=0;
		while ($row = mysqli_fetch_assoc($fetch)) {
			$id = $row['id'];
			$membno = $row['membno'];
			$name = $row['name'];
			$email = $row['email'];
			$password = $row['password'];
			$registereddate = $row['registereddate'];
			$sharedcapital = $row['sharedcapital'];
			$thrift = $row['thrift'];
			$mbf = $row['mbf'];
			$longtermloan = $row['longtermloan'];
			$emergencyloan = $row['emergencyloan'];
			$medicalloan = $row['medicalloan'];
			$hrmsno = $row['hrmsno'];
			$image = $row['image'];
			$ex1 = $row['ex1'];
			$ex2 = $row['ex2'];
			$ex3 = $row['ex3'];
			$ex4 = $row['ex4'];
			$ex5 = $row['ex5'];
			$ex6 = $row['ex6'];
			$i++;
?>


			<tr class="table">
				<td scope="row"><?php echo $id;?></td>
				<td><?php echo $membno;?></td>
				<td><?php echo $name;?></td>
				<td><?php echo $email;?></td>
				<td><?php echo $password;?></td>
				<td><?php echo $registereddate;?></td>
				<td><?php echo $sharedcapital;?></td>
				<td><?php echo $thrift;?></td>
				<td><?php echo $mbf;?></td>
				<td><?php echo $longtermloan;?></td>
				<td><?php echo $emergencyloan;?></td>
				<td><?php echo $medicalloan;?></td>
				<td><?php echo $hrmsno;?></td>				
				<td><?php echo $ex1;?></td>
				<td><?php echo $ex2;?></td>
				<td><?php echo $ex3;?></td>
				<td><?php echo $ex4;?></td>
				<td><?php echo $ex5;?></td>
				<td><?php echo $ex6;?></td>
				<td><?php echo "<img src='users/$image' width='100' height='100' />";?></td>
				<td>
				<ul class="list-group" id="actions">
					<li class="list-group-item">
						<a href="" id="view" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#viewUserModal">
						<i class="fa fa-eye fa-2x"></i> </a>
					<a class="" href="" id="edit" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#editUserModal">
						<i class="fa fa-edit fa-2x"></i></a> 
					<a class="" href="" id="delete" data-val="<?php echo $id;?>">
						<i class="fa fa-trash fa-2x"></i></a>
					</li>
				</ul>	
				</td>
				
    		</tr>


<?php
	}
}	
else{ 
	?>

	<tr><td>No Data Found</td></tr>
		
<?php	
}
?>

