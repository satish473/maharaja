<?php
	include("conn.php");
	$output='';
	$sql ="SELECT  * FROM 'users' WHERE name LIKE '%".$_POST['search']."%'";

	$result = mysqli_query($conn,$sql);
		if(mysqli_num_rows($result) > 0)
		{

?>

			<h4 align="center">Search Result</h4>
				<table class="table table-bordered table-striped table-hover">
  <thead>
    <tr class="text-uppercase">
      <th>Id</th>
      <th>memb no</th>
      <th>name</th>
      <th>email</th>
      <th>password </th> 
      <th>registered date</th> 
      <th>shared capital</th>
      <th>thrift</th>
      <th>mbf</th>
      <th>long term loan</th>
      <th>emergency loan</th>
      <th>medical loan</th>
      <th>hrms no</th>
      <th>image</th>
      <th>Action</th>
    </tr>
  </thead>


<tbody>


	

<?php
	 $i=0;
		while ($row = mysqli_fetch_assoc($result)) {
			$id = $row['id'];
			$membno = $row['membno'];
			$name = $row['name'];
			$email = $row['email'];
			$password = $row['password'];
			$registereddate = $row['registereddate'];
			$sharedcapital = $row['sharedcapital'];
			$thrift = $row['thrift'];
			$mbf = $row['mbf'];
			$longtermloan = $row['longtermloan'];
			$emergencyloan = $row['emergencyloan'];
			$medicalloan = $row['medicalloan'];
			$hrmsno = $row['hrmsno'];
			$image = $row['image'];
			$i++;
?>


			<tr class="table">
				<td scope="row"><?php echo $id;?></td>
				<td><?php echo $membno;?></td>
				<td><?php echo $name;?></td>
				<td><?php echo $email;?></td>
				<td><?php echo $password;?></td>
				<td><?php echo $registereddate;?></td>
				<td><?php echo $sharedcapital;?></td>
				<td><?php echo $thrift;?></td>
				<td><?php echo $mbf;?></td>
				<td><?php echo $longtermloan;?></td>
				<td><?php echo $emergencyloan;?></td>
				<td><?php echo $medicalloan;?></td>
				<td><?php echo $hrmsno;?></td>
				<td><?php echo "<img src='images/$image' width='100' height='100' />";?></td>
	
				<td>
				<ul class="list-group" id="actions">
					<li class="list-group-item">
						<a href="" id="view" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#viewUserModal">
						<i class="fa fa-eye fa-2x"></i> </a>
					<a class="" href="" id="edit" data-val="<?php echo $id;?>" data-toggle="modal" data-target="#editUserModal">
						<i class="fa fa-edit fa-2x"></i></a> 
					<a class="" href="" id="delete" data-val="<?php echo $id;?>">
						<i class="fa fa-trash fa-2x"></i></a>
					</li>
				</ul>	
				</td>
				
    		</tr>

</tbody>

</table>

<?php	
	}
	}
	else
	{
		echo 'Data Not Found';
	}
?>