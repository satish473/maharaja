<?php
	include("conn.php");
	$id = $_POST['id'];
	$sql = "SELECT * FROM users WHERE id = '$id'";
	$data = mysqli_query($conn,$sql);
		if(mysqli_num_rows($data) > 0){
			while($row = mysqli_fetch_assoc($data)){
				$viewData['id'] = $row['id'];
				$viewData['membno'] = $row['membno'];
				$viewData['name'] = $row['name'];
				$viewData['email'] = $row['email'];
				$viewData['password'] = $row['password'];
				$viewData['registereddate'] = $row['registereddate'];
				$viewData['sharedcapital'] = $row['sharedcapital'];
				$viewData['thrift'] = $row['thrift'];
				$viewData['mbf'] = $row['mbf'];
				$viewData['longtermloan'] = $row['longtermloan'];
				$viewData['emergencyloan'] = $row['emergencyloan'];
				$viewData['medicalloan'] = $row['medicalloan'];
				$viewData['hrmsno'] = $row['hrmsno'];
				
				$viewData['ex1'] = $row['ex1'];
				$viewData['ex2'] = $row['ex2'];
				$viewData['ex3'] = $row['ex3'];
				$viewData['ex4'] = $row['ex4'];
				$viewData['ex5'] = $row['ex5'];
				$viewData['ex6'] = $row['ex6'];
				$viewData['image'] = $row['image'];		
					
			}
			echo json_encode($viewData);
			
		}
		else{ 

		?>
			<tr>
				<td>No Data Found!</td>
			</tr>
		<?php	
		} 
	?>