
    $(document).ready(function(){

// Insert Data   
      $('#uploadUser').submit(function(e){

      e.preventDefault();
      
      var membno = $('#membno').val();
      var name = $('#name').val();
      var email = $('#email').val();
      var password = $('#password').val(); 
      var registereddate = $('#registereddate').val();
      var sharedcapital = $('#sharedcapital').val();
      var thrift = $('#thrift').val();
      var mbf = $('#mbf').val(); 
      var longtermloan = $('#longtermloan').val();
      var emergencyloan = $('#emergencyloan').val();
      var medicalloan = $('#medicalloan').val();
      var hrmsno = $('#hrmsno').val();      
      var ex1 = $('#ex1').val();
      var ex2 = $('#ex2').val();
      var ex3 = $('#ex3').val();
      var ex4 = $('#ex4').val();
      var ex5 = $('#ex5').val();
      var ex6 = $('#ex6').val();

      var image = $('#image').val();

        $.ajax({
        url: $(this).attr('action'),
        //url: 'insert_user.php',
        type: 'post',
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success:function(data){ 
          $("#addPostModal").hide();
          location.reload();
          
        }, error: function(){

        }   
      });
    
    });

});

//Fetch and Pagination
 $(document).ready(function(data){
            var empDataTable = $('#empTable').DataTable({
                'processing': true,
                'serverSide': true,
                'serverMethod': 'post',
                'ajax': {
                    'url':'ajaxfile.php'
                },
                pageLength: 16,
                'columns': [
                    { data: 'id'},
                    { data: 'membno'},
                    { data: 'name'},
                    { data: 'email'},
                    { data: 'password'},  
                    { data: 'registereddate'},
                    { data: 'sharedcapital'},
                    { data: 'thrift'},
                    { data: 'mbf'}, 
                    { data: 'longtermloan'},
                    { data: 'emergencyloan'},
                    { data: 'medicalloan'},
                    { data: 'hrmsno'},                    
                    { data: 'ex1'},
                    { data: 'ex2'},
                    { data: 'ex3'},
                    { data: 'ex4'},
                    { data: 'ex5'},
                    { data: 'ex6'},
                    { data: 'image'},
                    { data: 'action'}

                ]
            });
        });



        
//To View the details of specific User
$(document).on('click', '#view', function(){
  var id = $(this).attr('data-val');
    $.ajax({
      url: 'viewUser.php',
      type: "POST", 
      data: {
        id:id,
      },

      dataType: "JSON",
      success: function(data){

        var img = $('<img id="view_image" width="100px" height="100px" style="margin-left:auto;margin-right:auto;display:block;border-radius:50%;">');

          img.attr('src', "users/"+data.image);
          img.appendTo('#view_image');
            $('#view_membno').text(data.membno);
            $('#view_name').text(data.name);
            $('#view_email').text(data.email);
            $('#view_registereddate').text(data.registereddate);
            $('#view_sharedcapital').text(data.sharedcapital);
            $('#view_thrift').text(data.thrift);
            $('#view_mbf').text(data.mbf);
            $('#view_longtermloan').text(data.longtermloan);
            $('#view_emergencyloan').text(data.emergencyloan);
            $('#view_medicalloan').text(data.medicalloan);
            $('#view_hrmsno').text(data.hrmsno);
            $('#view_ex1').text(data.ex1);
            $('#view_ex2').text(data.ex2);
            $('#view_ex3').text(data.ex3);
            $('#view_ex4').text(data.ex4);
            $('#view_ex5').text(data.ex5);
            $('#view_ex6').text(data.ex6);

    } 
  });
  });

 //To Edit the Records
 $(document).on('click', '#edit', function(){
    var id = $(this).attr('data-val');
    //alert(id);
    $.ajax({
      url: 'viewUser.php',
      type: "POST",
      data: {id:id},

      success: function(data){
        var json = $.parseJSON(data);
        //alert(json.image);
        $('#user_id').val(json.id);
        $('#umembno').val(json.membno);
        $('#uname').val(json.name);
        $('#uemail').val(json.email);
        $('#upassword').val(json.password);
        $('#uregistereddate').val(json.registereddate);
        $('#usharedcapital').val(json.sharedcapital);
        $('#uthrift').val(json.thrift);
        $('#umbf').val(json.mbf);
        $('#ulongtermloan').val(json.longtermloan);
        $('#uemergencyloan').val(json.emergencyloan);
        $('#umedicalloan').val(json.medicalloan);
        $('#uhrmsno').val(json.hrmsno);
        $('#uex1').val(json.ex1);
        $('#uex2').val(json.ex2);
        $('#uex3').val(json.ex3);
        $('#uex4').val(json.ex4);
        $('#uex5').val(json.ex5);
        $('#uex6').val(json.ex6);
        
        var img = $('<img id="image" width="100" height="100" id="image">');
        img.attr('src', "users/"+json.image);
        $("#himage").val(json.image);
        img.appendTo('#pimage');
       }
     });

 });

 $(document).ready(function(){
    $("#updateuser").click(function(e){

        e.preventDefault();
        var form_data = new FormData($('#updUser')[0]);
        var fileToUpload = $('#uimage').prop('files')[0];
        
        var id = $('#user_id').val();
        var membno = $('#umembno').val();
        var name = $('#uname').val();
        var email = $('#uemail').val();
        var password = $('#upassword').val();
        var registereddate = $('#uregistereddate').val();
        var sharedcapital = $('#usharedcapital').val();
        var thrift = $('#uthrift').val();
        var mbf = $('#umbf').val();
        var longtermloan = $('#ulongtermloan').val();
        var emergencyloan = $('#uemergencyloan').val();
        var medicalloan = $('#umedicalloan').val();
        var hrmsno = $('#uhrmsno').val();        
        var ex1 = $('#uex1').val();
        var ex2 = $('#uex2').val();
        var ex3 = $('#uex3').val();
        var ex4 = $('#uex4').val();
        var ex5 = $('#uex5').val();
        var ex6 = $('#uex6').val();
        var image = (fileToUpload !== undefined) ? fileToUpload : $('#himage').val();
        
      if(membno !="" && name !="" && email !="" && password !="" && registereddate !="" && password !="" && sharedcapital !="" && thrift !="" && mbf !="" && longtermloan !=""&& emergencyloan !="" && medicalloan !="" && hrmsno !="")
          {
            $.ajax({
              url: "update_user_code.php",
              type: "POST",
              data: form_data,
              processData: false,
              contentType: false,
              success: function(data)
                {
                  $("#editUserModal").hide();
                  alert(data);
                  location.reload();
                  // console.log(data);
                  // return false;
                }
              });
          }
            else{
              alert("Please Fill all the details");
            }
        });

    });

// //To Delete Record
$(document).on('click', '#delete', function(){
  var id = $(this).attr('data-val');
  $.ajax({
    url: 'delete.php',
    type: "POST",
    data: {id:id},

    success: function(data){
      alert(data);
    }
  });
});

