<?php include("conn.php");
	session_start();
	if(!$_SESSION['admin_name']){
		header('location: admin_login.php');
		
	}
	else{

?>
<!DOCTYPE html>
<html>

<head>
	<title>Admin Panel</title>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <link href='https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="fontawesome/css/all.css">
  
</head>

<body>

<?php include("admin_header.php");?>

<?php include("fetch_all_users.php");?>

<?php include("insert_user_dom.php");?>

<?php include("view_specific_user_dom.php");?>

<?php include("update_user.php");?>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
 	<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
	<script src="ajax.js"></script>


</body>
</html>

<?php
}
?>