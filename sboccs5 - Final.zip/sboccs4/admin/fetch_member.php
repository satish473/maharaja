<!--Read Data-->
  <table class="table table-responsive table-bordered table-hover">
  <thead>
    <tr class="text-uppercase">
      <th>Id</th>
      <th>memb no</th>
      <th>name</th>
      <th>email</th>
      <th>password </th> 
      <th>registered date</th> 
      <th>shared capital</th>
      <th>thrift</th>
      <th>mbf</th>
      <th>long term loan</th>
      <th>emergency loan</th>
      <th>medical loan</th>
      <th>hrms no</th>
      <th>image</th>
      <th>Action</th>
    </tr>
  </thead>
    <tbody id="userdata">
  <!--Fetch Data-->

    </tbody>
  </table>
</div>